<div>
    <!-- Slider Principal -->
    <div class="swiper slider-principal">
      <div class="swiper-wrapper">
        <?php $__currentLoopData = $cursos_detacados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destacado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="swiper-slide">
                <div class="contenido shadow-2xl px-4 py-4 ">
                    <h3 class="title text-2xl font-bold"><?php echo e($destacado->curso->nombre); ?></h3>
                    <div class="price"><?php echo e($destacado->curso->precio); ?></div>
                    <div class="description"><?php echo e($destacado->curso->descripcion_corta); ?></div>
                    <div class="read_more"><a href="<?php echo e($destacado->curso->url()); ?>">Ver Curso</a></div>
                </div>
                <div class="imagen">
                    <img
                        class=" "
                        src="<?php echo e($destacado->curso->imagen); ?>"
                        alt="image"
                    />
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="swiper-button-next"></div>
      <div class="swiper-button-prev"></div>
    </div>

    <!-- Categorías para ti  -->
    <div class="que-aprender-ahora mt-5">
        <h3 class="text-xl font-bold">Temas de interés</h3>
        <div class="temas grid grid-cols-4 gap-4 w-full">
            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="#" class="tema text-center border-2 border-black py-2"><?php echo e($categoria->nombre); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <!-- Que aprender ahora  -->
    <div class="que-aprender-ahora mt-5">
        <h3 class="text-xl font-bold">Qué aprender ahora</h3>
        <div class="temas grid grid-cols-4 gap-4 w-full">
            <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tema text-center mb-4">
                    <a href="<?php echo e($curso->url()); ?>" class="block w-full h-32 bg-center" style="background-image: url(<?php echo e($curso->imagen); ?>)"></a>
                    <div class="text-left px-2">
                        <h3 class="title text-lg font-bold"><?php echo e($curso->nombre); ?></h3>
                        <div class="price text-sm"><?php echo e($curso->autor->name); ?></div>
                        <div class="price text-sm font-bold"><?php echo e($curso->precio); ?></div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <!-- Categorías para ti  -->
    <div class="que-aprender-ahora mt-5">
        <h3 class="text-xl font-bold">Top Docentes</h3>
        <div class="temas grid grid-cols-4 gap-4 w-full">
            <?php $__currentLoopData = $autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="#" class="tema text-center border-2 border-black py-2"><?php echo e($autor->name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH D:\laragonf\www\cursos\resources\views/livewire/inicio.blade.php ENDPATH**/ ?>