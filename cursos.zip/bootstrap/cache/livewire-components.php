<?php return array (
  'inicio' => 'App\\Http\\Livewire\\Inicio',
  'users.permissions' => 'App\\Http\\Livewire\\Users\\Permissions',
  'users.roles' => 'App\\Http\\Livewire\\Users\\Roles',
);